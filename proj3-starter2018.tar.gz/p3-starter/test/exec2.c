/*
 * exec2.c
 */

#include <syscall.h>

void print(char *s)
{
	int len = 0;

	while (*s++)
		++len;

	Write(s-len-1, len, 1);
}

main()
{
	print("Greetings from exec2.c\n");
//	Exit(0);
}
